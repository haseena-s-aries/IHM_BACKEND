from io import BytesIO
from pathlib import Path

from pypdf import PdfReader
from reportlab.lib.utils import ImageReader
from reportlab.pdfgen import canvas

def make_appendix_four_location_plan_pages(page_number=1, job_id=None):
    base_dir = Path(__file__).resolve().parent.parent
    project_root = Path(__file__).resolve().parents[2]
    source_pdf = base_dir / "templates" / "report.pdf"

    if job_id is None:
        return []

    map_image = (
        project_root
        / "wwwroot"
        / "reports"
        / "ihm"
        / str(job_id)
        / "appendix4-ga-marker-map.png"
    )

    if not source_pdf.exists():
        return []

    reader = PdfReader(str(source_pdf))
    page_index = max(int(page_number) - 1, 0)

    if page_index >= len(reader.pages):
        return []

    page = reader.pages[page_index]
    print("Appendix 4 media box:", page.mediabox)
    print("Appendix 4 crop box:", page.cropbox)
    print("Appendix 4 rotation:", page.rotation)
    if page.rotation:
        page.transfer_rotation_to_content()

    image_exists = map_image.exists()

    page_width = float(page.mediabox.width)
    page_height = float(page.mediabox.height)

    print("Appendix 4 page size:", page_width, page_height)
    print("Appendix 4 rotation after fix:", page.rotation)

    packet = BytesIO()
    c = canvas.Canvas(packet, pagesize=(page_width, page_height))

    c.setFillColorRGB(1, 1, 1)

    c.rect(100, 480, 1660 - 100, 900 - 480, fill=1, stroke=0)
    c.rect(100, 35, 1940 - 100, 540 - 35, fill=1, stroke=0)

    image_x = 60
    image_y = 40
    image_right = 1660
    image_top = 900

    image_width = image_right - image_x
    image_height = image_top - image_y

    if image_exists:
        c.drawImage(
            ImageReader(str(map_image)),
            image_x,
            image_y,
            width=image_width,
            height=image_height,
            preserveAspectRatio=True,
            anchor="c",
            mask="auto",
        )

    c.save()
    packet.seek(0)

    overlay_page = PdfReader(packet).pages[0]
    page.merge_page(overlay_page)

    return [page]